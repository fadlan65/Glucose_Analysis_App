import numpy as np 
import pandas as pd
import pickle
from flask import Flask, render_template, request

# global variabel
h1_hasil = ''
error = 0
            
def info_number(data):
    global error
    if data == '':
        error += 1
        return '*data tidak boleh kosong'
    else:
        data = float(data)
        if data <= 0:
            error += 1
            return '*nilai harus lebih dari 0'
    return ''

def info_category(data):
    global error
    if data == '':
        error += 1
        return '*pilih salah satunya'
    return ''

alphabet = ' ,.'
for i in range(97,123):
    alphabet += chr(i)


app = Flask(__name__)
@app.route('/', methods = ['POST', 'GET'])

def index():
    if request.method == "POST":
        global error

        nama = request.form['nama']
        error_nama =''
        if len(nama) <= 0:
            error_nama = '*nama tidak boleh kosong'
            error += 1
        else:
            for i in nama:
                if str(i).lower() not in alphabet:
                    error_nama = '*nama tidak valid'
                    error += 1
                    
        x0 = request.form['sex']
        e_x0 = info_category(x0)

        x1 = request.form['umur']
        e_x1 = info_number(x1)

        # tahap analisi
        if(error == 0):
            # load model ML
            model_tree = pickle.load(open('model/tree_method.sav', 'rb'))

            X_new = np.array((x1))
            X_new = np.reshape(X_new, (1, -1))

            # analisis
            pred = model_tree.predict(X_new)

            if int(x0) == 1:
                hasil = 'tidak beresiko'
                msg4 = '(Anda Laki-laki).'
            else:
                if(pred[0] == 1):
                    hasil = 'tidak beresiko'
                    msg4 = '(Anda sehat).'
                else:
                    hasil = 'beresiko'
                    msg4 = '(Anda sakit).'

            # output
            h1 = 'Hasil Analisis:'
            msg1 = 'Dari informasi yang diperoleh, atas nama'
            msg2 = 'saat ini Anda'
            msg3 = 'menderita kanker payudara'
            
            return render_template('index.html', 
            h1=h1, 
            nama = nama, 
            msg1 = msg1, 
            msg2 = msg2, 
            hasil= hasil, 
            msg3 = msg3, 
            msg4 = msg4 )

        else:
            error = 0
            return render_template('index.html', 
            error_nama = error_nama, 
            error_x0 = e_x0, 
            error_x1 = e_x1 )
    else:
        return render_template('index.html')

if __name__ == "__main__":
    app.run(debug=True)